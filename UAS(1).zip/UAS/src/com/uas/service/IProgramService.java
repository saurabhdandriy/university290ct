package com.uas.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;


public interface IProgramService {

	String addProgramDetails(ProgramBean pb);

	int deleteProgramDetails(String deleteProgramName);

	ArrayList<ProgramBean> viewAllProgramDetails();

	ProgramBean updateProgramDetails(String programName);

	String updateNewProgramDetails(ProgramBean upbo);

	ArrayList<ProgramBean> viewAllProName();

}
