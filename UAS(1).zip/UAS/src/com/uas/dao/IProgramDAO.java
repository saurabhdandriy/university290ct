package com.uas.dao;

import java.util.ArrayList;

import com.uas.bean.ProgramBean;

public interface IProgramDAO {

	String addProgramDetails(ProgramBean pb);

	int deleteProgramDetails(String deleteProgramName);

	ArrayList<ProgramBean> viewAllProgramDetails();

	ProgramBean updateprogramDetails(String programName);

	String updateNewProgramDetails(ProgramBean upbo);

	ArrayList<ProgramBean> viewAllProName();

}
