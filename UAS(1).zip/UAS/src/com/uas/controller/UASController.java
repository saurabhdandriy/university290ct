package com.uas.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;





import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;
import com.uas.service.IProgramService;
import com.uas.service.IScheduleService;

@Controller
public class UASController {

	@Autowired
	private IScheduleService iss;
	@Autowired
	private IProgramService ips;
	
	@RequestMapping("admin")
	public String goAdminPage()
	{
		return "admin";
	}
	
	@RequestMapping("program")
	public String goProgramPage()
	{
		return "program";
	}

	@RequestMapping("addprogramdetails")
	public String goaddprogramPage(Model m)
	{
		m.addAttribute("programObj",new ProgramBean());
		
		return "addprogramdetails";
	}

	
	
	
	@RequestMapping(value="addprogramsuccess",method=RequestMethod.POST)
	public String addprogramDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
	{
	String target=null;
		String progName;
		progName=ips.addProgramDetails(pb);
		if(progName != null)
		{
			m.addAttribute("msg","Program data added  successfully your program is...");
			m.addAttribute("programName", progName);
			target="addprogramsuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	

	@RequestMapping("deleteprogramdetails")
	public String goDeleteProgramPage(Model m)
	{
		m.addAttribute("programObj",new ProgramBean());
		return "deleteprogramdetails";
	}
	
	@RequestMapping(value="deleteprogramsuccess",method=RequestMethod.POST)
	public String deleteProgramDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
	{
	String target=null;
		String deleteProgramName=pb.getProgramName();
		int result;
		result=ips.deleteProgramDetails(deleteProgramName);
		if(result > 0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteProgramId", deleteProgramName);
			target="deletesuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	
	
	@RequestMapping("viewprogramdetails")
	public ModelAndView viewAllProgram()
	{
		ModelAndView mv= new ModelAndView();
		ArrayList<ProgramBean> proglist= ips.viewAllProgramDetails();
		mv.setViewName("viewprogsuccess");
		mv.addObject("progdata",proglist);
		return mv;
	}
	



	@RequestMapping("updateprogramdetails")
	public String goUpdateProgramPage(Model m)
	{
		m.addAttribute("programObj", new ProgramBean());
		return "updateprogramdetails";
	}
	


@RequestMapping(value="updatenewprogramdetails",method=RequestMethod.POST)
public String updateScheduleDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
{
	String target=null;
	String programName=pb.getProgramName();
	ProgramBean result=ips.updateProgramDetails(programName);
	
	if(result!=null)
	{
		
		m.addAttribute("updatelist",result);
		target="updatenewprogramdetails";	
	}
	else
	{
		target="home";
		
	}
	return target;
}


@RequestMapping(value="updateprogramsuccess",method=RequestMethod.POST)
public String updateScheduleDetailssuccessPage(Model m,@ModelAttribute("programObj") ProgramBean upbo)
{
String target=null;
	
	String result=ips.updateNewProgramDetails(upbo);
	if(result!=null)
	{
		m.addAttribute("msg","programs data updated  successfully The schedule id is...");
		m.addAttribute("programName",result);
		target="updateprogramsuccess";
	}
	else
	{
		target="home";
	}
	return target;
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("schedule")
	public String goSchedulePage()
	{
		return "schedule";
	}

	@RequestMapping("addscheduledetails")
	public String goAddSchedulePage(Model m)
	{
		
		ArrayList<ProgramBean> prolist = ips.viewAllProName();
		
		m.addAttribute("scheduleObj",new ScheduleBean());
		m.addAttribute("programName",prolist);
		return "addscheduledetails";
	}
	

	
	@RequestMapping(value="addsuccess",method=RequestMethod.POST)
	public String addScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
	{
	String target=null;
		int sid;
		sid=iss.addScheduleDetails(sb);
		if(sid>0)
		{
			m.addAttribute("msg","schedule data added  successfully The schedule id is...");
			m.addAttribute("scheduleId", sid);
			target="addsuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	
	
	@RequestMapping("deletescheduledetails")
	public String goDeleteSchedulePage(Model m)
	{
		m.addAttribute("scheduleObj",new ScheduleBean());
		return "deletescheduledetails";
	}
	
	





	@RequestMapping("viewscheduledetails")
	public ModelAndView viewAll()
	{
		ModelAndView mv= new ModelAndView();
		ArrayList<ScheduleBean> schelist= iss.viewAllScheduleDetails();
		mv.setViewName("viewsuccess");
		mv.addObject("sechdata",schelist);
		return mv;
	}




@RequestMapping(value="deletesuccess",method=RequestMethod.POST)
public String deleScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
{
String target=null;
	int deleteScheduleId=sb.getScheduleProgramId();
	int result;
	result=iss.deleteScheduleDetails(deleteScheduleId);
	if(result>0)
	{
		m.addAttribute("msg","Rows deleted successfully");
		m.addAttribute("deleteid", deleteScheduleId);
		target="deletesuccess";
	}
	else
	{
		target="home";
	}
	return target;
}

@RequestMapping("updatescheduledetails")
public String goUpdateSchedulePage(Model m)
{
	m.addAttribute("scheduleObj", new ScheduleBean());
	return "updatescheduledetails";
}




@RequestMapping(value="updatenewscheduledetails",method=RequestMethod.POST)
public String updateScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
{
	String target=null;
	int scheId=sb.getScheduleProgramId();
	ScheduleBean result=iss.updateScheduleDetails(scheId);
	if(result!=null)
	{
		
		m.addAttribute("updatelist",result);
		target="updatenewscheduledetails";	
	}
	else
	{
		target="home";
		
	}
	return target;
}

@RequestMapping(value="updateschedulesuccess",method=RequestMethod.POST)
public String updateScheduleDetailssuccessPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean usbo)
{
String target=null;
	
	int result=iss.updateNewScheduleDetails(usbo);
	if(result>0)
	{
		m.addAttribute("msg","schedule data updated  successfully The schedule id is...");
		m.addAttribute("scheduleId",result);
		target="updateschedulesuccess";
	}
	else
	{
		target="home";
	}
	return target;
}


/*
@RequestMapping("updateprogram")
public ModelAndView updateScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
{
	ModelAndView mv= new ModelAndView();
	String target=null;
	int scheId=sb.getScheduleProgramId();
	ScheduleBean result=iss.updateScheduleDetails(scheId);
	if(result!=null)
	{
		mv.setViewName("updatedetails");
		mv.addObject("updatelist", result);
	}
	else
	{
		mv.setViewName("home");
	}
	
	return mv;
}*/







}
